<?php
/**
 * Created by PhpStorm.
 * User: maciejklowan
 * Date: 29/04/16
 * Time: 13:14
 */

namespace CodesWholesale\Resource;


class ImageType extends Resource
{
    const SMALL = 'SMALL';
    const MEDIUM = 'MEDIUM';
}