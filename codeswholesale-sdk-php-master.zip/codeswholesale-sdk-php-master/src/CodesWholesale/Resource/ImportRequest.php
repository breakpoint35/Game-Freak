<?php
/**
 * Created by PhpStorm.
 * User: maciejklowan
 * Date: 24/08/2018
 * Time: 11:11
 */

namespace CodesWholesale\Resource;


class ImportRequest extends Resource
{
    const FILTERS = "filters";
    const TERRITORY = "territory";
    const WEB_HOOK_URL = "webHookUrl";
}