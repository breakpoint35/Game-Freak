<?php
/**
 * Created by PhpStorm.
 * User: maciejklowan
 * Date: 16/09/2017
 * Time: 13:08
 */

namespace CodesWholesale\Resource;


class ProductDescriptionFieldContainer
{
    const PHOTO = "Photo";
    const RELEASE = "Release";
    const VIDEO = "Video";
    const FACT_SHEET = "FactSheet";
    const LOCALIZED_TITLE = "LocalizedTitle";
}