<?php

namespace CodesWholesale\Util;

class Version
{
    const SDK_VERSION = '0.0.1.beta';
}
